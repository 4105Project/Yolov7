# Sidewalk > 2022-12-12 2:00pm
https://universe.roboflow.com/uncc-algo-2/sidewalk-o14u9

Provided by a Roboflow user
License: CC BY 4.0

